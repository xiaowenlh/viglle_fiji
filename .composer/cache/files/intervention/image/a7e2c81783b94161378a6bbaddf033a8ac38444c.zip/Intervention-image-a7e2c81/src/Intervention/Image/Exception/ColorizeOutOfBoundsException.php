<?php

namespace Intervention\Image\Exception;

class ColorizeOutOfBoundsException extends \OutOfBoundsException
{
    # nothing to override
}
