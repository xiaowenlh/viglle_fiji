<?php

namespace Intervention\Image\Exception;

class ImageNotWritableException extends \RuntimeException
{
    # nothing to override
}
