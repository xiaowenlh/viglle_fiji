<?php

namespace Intervention\Image\Exception;

class ImageNotFoundException extends \RuntimeException
{
    # nothing to override
}
