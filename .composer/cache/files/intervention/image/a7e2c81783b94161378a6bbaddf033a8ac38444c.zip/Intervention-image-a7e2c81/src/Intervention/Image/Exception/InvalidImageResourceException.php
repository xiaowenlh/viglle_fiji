<?php

namespace Intervention\Image\Exception;

class InvalidImageResourceException extends \RuntimeException
{
    # nothing to override
}
