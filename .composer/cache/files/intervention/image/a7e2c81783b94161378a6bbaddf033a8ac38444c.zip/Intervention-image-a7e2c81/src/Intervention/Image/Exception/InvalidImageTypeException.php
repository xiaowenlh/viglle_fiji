<?php

namespace Intervention\Image\Exception;

class InvalidImageTypeException extends \RuntimeException
{
    # nothing to override
}
