<?php

namespace Intervention\Image\Exception;

class InvalidImageDataStringException extends \RuntimeException
{
    # nothing to override
}
