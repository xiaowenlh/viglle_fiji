<?php

namespace Intervention\Image\Exception;

class ImageCacheNotFoundException extends \RuntimeException
{
    # nothing to override
}
