<?php

namespace Intervention\Image\Exception;

class ContrastOutOfBoundsException extends \OutOfBoundsException
{
    # nothing to override
}
