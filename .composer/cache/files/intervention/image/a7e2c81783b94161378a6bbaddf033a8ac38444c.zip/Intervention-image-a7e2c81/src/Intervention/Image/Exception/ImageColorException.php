<?php

namespace Intervention\Image\Exception;

class ImageColorException extends \RuntimeException
{
    # nothing to override
}
