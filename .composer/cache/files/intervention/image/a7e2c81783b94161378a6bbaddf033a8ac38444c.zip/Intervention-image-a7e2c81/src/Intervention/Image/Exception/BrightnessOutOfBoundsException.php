<?php

namespace Intervention\Image\Exception;

class BrightnessOutOfBoundsException extends \OutOfBoundsException
{
    # nothing to override
}
