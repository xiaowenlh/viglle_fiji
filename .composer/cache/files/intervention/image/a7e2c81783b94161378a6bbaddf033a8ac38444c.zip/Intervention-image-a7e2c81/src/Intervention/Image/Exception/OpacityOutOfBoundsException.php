<?php

namespace Intervention\Image\Exception;

class OpacityOutOfBoundsException extends \OutOfBoundsException
{
    # nothing to override
}
