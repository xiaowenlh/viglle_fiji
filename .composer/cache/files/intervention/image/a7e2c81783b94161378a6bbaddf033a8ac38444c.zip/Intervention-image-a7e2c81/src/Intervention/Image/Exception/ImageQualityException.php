<?php

namespace Intervention\Image\Exception;

class ImageQualityException extends \RuntimeException
{
    # nothing to override
}
