<?php

namespace Intervention\Image\Exception;

class ExifFunctionsNotAvailableException extends \RuntimeException
{
    # nothing to override
}
