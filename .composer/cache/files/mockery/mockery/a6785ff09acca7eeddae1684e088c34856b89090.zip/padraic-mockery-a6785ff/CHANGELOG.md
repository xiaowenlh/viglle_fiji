# 0.9.0 (2014-XX-XX)

* Allow mocking classes with final __wakeup() method
* Quick definitions are now always `byDefault`
* Allow mocking of protected methods with `shouldAllowMockingProtectedMethods`
* Support offical Hamcrest package
* Generator completely rewritten
