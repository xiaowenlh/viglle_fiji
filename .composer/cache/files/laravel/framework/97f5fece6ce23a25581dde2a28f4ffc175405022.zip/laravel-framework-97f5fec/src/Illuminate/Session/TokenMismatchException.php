<?php namespace Illuminate\Session;

class TokenMismatchException extends \Exception {}